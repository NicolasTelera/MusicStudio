package upmc.stl.m1.musicstudio.fragment;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import upmc.stl.m1.musicstudio.tools.Atom;
import upmc.stl.m1.musicstudio.tools.Block;
import upmc.stl.m1.musicstudio.R;
import upmc.stl.m1.musicstudio.task.ConvertToMP4Task;
import upmc.stl.m1.musicstudio.task.PlaySoundTask;
import upmc.stl.m1.musicstudio.task.RecordSoundTask;
import upmc.stl.m1.musicstudio.tools.DrawSoundView;
import upmc.stl.m1.musicstudio.tools.Mpeg4Data;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TrackFragment_old.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TrackFragment_old#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TrackFragment extends Fragment {

    // Listener de communication entre Activity et Fragment
    private OnFragmentInteractionListener listener;

    // Variables
    private int id;
    private String path;
    private long duration;
    private MediaPlayer player;
    private RecordSoundTask recordTask;
    private ConvertToMP4Task convertTask;
    private PlaySoundTask playTask;

    public static TrackFragment newInstance() {
        TrackFragment fragment = new TrackFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    public TrackFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle params = this.getArguments();
        this.id = params.getInt("id");
        this.path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC + "/MusicStudio/sample" + this.id).getPath();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_track, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // LISTENER sur le bouton d'enregistrement
        Button buttonRecord = (Button) getView().findViewById(R.id.track_record_button);
        buttonRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                record(v);
            }
        });

        // LISTENER sur le bouton de lecture
        Button buttonPlay = (Button) getView().findViewById(R.id.track_play_button);
        buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                play();
            }
        });

    }

    public void onButtonPressed(Uri uri) {
        if (listener != null) {
            listener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    /**********************************************************************************************
     *
     * INTERFACES DE COMMUNICATION
     *
     **********************************************************************************************/

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        public void onFragmentInteraction(Uri uri);
    }

    /**
     * Nécessaire pour attendre la fin de la tâche asynchrone de conversion avant
     * de dessiner le bloc sur la piste.
     */
    public interface FragmentCallback {
        public void onTaskDone();
    }

    /**********************************************************************************************
     *
     * FONCTIONS DE MANIPULATION DE LA PISTE
     *
     **********************************************************************************************/

    /**
     * Enregistre un son.
     * @param view
     */
    public void record(View view) {

        Button recordButton = (Button) getView().findViewById(R.id.track_record_button);

        if(this.recordTask == null || this.recordTask.getStatus() == AsyncTask.Status.FINISHED) {
            // Lancement de l'enregistrement
            this.recordTask = new RecordSoundTask(this, this.path);
            this.recordTask.execute();
            recordButton.setText("STOP");
            // lancement de l'enregistrement
            this.duration = System.nanoTime();
        } else {
            this.duration = System.nanoTime() - this.duration;
            //System.out.println("duréé de la prise : " + (duration/1E9));
            // Fin de l'enregistrement
            this.recordTask.setIsRecording(false);
            recordButton.setText("RECORD");
            // Lancement de la tâche de conversion
            this.convertTask = new ConvertToMP4Task(this, this.path, new FragmentCallback() {
                @Override
                public void onTaskDone() {
                    // Préparation du block
                    Block block = new Block("sample" + id, 0, (int)((duration/1E9)*50));
                    addBlock(block);
                }
            });
            convertTask.execute();
        }

    }

    /**
     * Lit un son préalablement enregistré.
     */
    public void play() {

        Button recordButton = (Button) getView().findViewById(R.id.track_play_button);

        if(this.playTask == null || this.player == null) {
            this.player = new MediaPlayer();
            this.playTask = new PlaySoundTask(this, this.path, this.player);
            this.playTask.execute();
            recordButton.setText("STOP");
        } else {
            this.player.stop();
            this.player.release();
            this.playTask = null;
            recordButton.setText("PLAY");
        }

    }

    // fonction d'ajout d'un bloc sur une piste
    public void addBlock(final Block block) {

        // préparation d'un LinearLayout pour représenter le bloc
        LinearLayout layoutBlock = new LinearLayout(getActivity());
        //LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(new ActionBar.LayoutParams(block.getLength(), ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(block.getLength(), ViewGroup.LayoutParams.MATCH_PARENT);
        params.setMargins(block.getStart(), 0, 0, 0);
        layoutBlock.setLayoutParams(params);
        layoutBlock.setOrientation(LinearLayout.VERTICAL);
        layoutBlock.setBackgroundColor(0xfffffd11);

        // ajout d'un listener sur les mouvements du doigt pour déplacer le bloc
        layoutBlock.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int offset = (int) (event.getRawX() - v.getX());
                LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) v.getLayoutParams();
                if(event.getAction() == MotionEvent.ACTION_MOVE) {

                    int diff = 0;
                    int x = (int) v.getX();
                    int historySize = event.getHistorySize();
                    if(historySize > 0) {
                        diff = (int) (event.getX() - event.getHistoricalX(historySize -1));
                        if(diff > 0) {
                            x = x + diff;
                        } else {
                            x = x - Math.abs(diff);
                        }

                        if(x<0) x=0;
                        params.setMargins(x,0,0,0);
                        block.setStart(x);
                    }
                }
                v.setLayoutParams(params);
                return true;
            }
        });

        // ajout du block à la piste
        LinearLayout piste = (LinearLayout) getView().findViewById(R.id.track_sound_block);
        piste.addView(layoutBlock);

        // enregistrement du bloc dans la table de hachage
        //this.blocs.put(block, layoutBlock);

        // représentation du son dans le bloc généré
        this.drawSound(layoutBlock, block.getLength());

    }

    // fonction pour dessiner la forme du son
    public void drawSound(LinearLayout layoutBloc, int width) {

        // récupération du bloc à dessiner
        LinearLayout piste = (LinearLayout) getView().findViewById(R.id.track_sound_block);

        // traitement du fichier MPEG-4
       int[] data = parseMPEG4File(width);

        // lancement du dessin de la forme d'onde
        Bitmap bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        DrawSoundView view = new DrawSoundView(getActivity(), piste.getHeight(), data);
        layoutBloc.addView(view);

    }

    // fonction pour traiter les données du fichier MPEG-4 à dessiner (PASSER CETTE METHODE DANS MPEG4DATA ?)
    public int[] parseMPEG4File(int width) {

        try {

            // Récupération des données dans un tableau de bytes
            File file = new File(this.path + ".mp4");
            DataInputStream dis = new DataInputStream(new FileInputStream(file));
            byte[] data = new byte[dis.available()];
            dis.readFully(data);

            // PARSING DU FICHIER MPEG-4
            Mpeg4Data atoms = new Mpeg4Data(data);
            byte[] temp = new byte[4];
            StringBuilder builder = null;
            int index = 0;
            boolean done = false;

            // parsing complet du fichier pour récupérer les 4 atomes principaux
           do {

                builder = new StringBuilder();
                Atom atom = new Atom(index);

                // récupération de la longueur de l'atome
                for (int i=0 ; i<4 ; i++) builder.append(String.format("%02x", data[index + i]));
                atom.setSize(Integer.parseInt(builder.toString(), 16));

                // récupération des données de l'atome
                temp = new byte[atom.getSize()];
                for (int i=0 ; i<atom.getSize() ; i++) temp[i] = data[index + i];
                atom.setData(temp);

                // récupération du nom de l'atome
                temp = new byte[4];
                for (int i=0 ; i<4 ; i++) temp[i] = atom.getData()[i + 4];
                atom.setName(new String(temp, "UTF-8"));

                atoms.addAtom(atom);
                if((index += atom.getSize()) >= data.length) done = true;

            } while(!done);

            System.out.println("====================================================");
            System.out.println("LONGUEUR TOTALE DES DONNEES : " + data.length);
            for(Atom a : atoms.getAtoms()) System.out.println(a);
            System.out.println("====================================================");

            // récupération du nombre d'entrées (chunks) dans le média et de son début
            atoms.findMoovInfos();
            //return atoms.computeDataToDraw(width);
            return atoms.computeDataToDrawNew();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }

}
