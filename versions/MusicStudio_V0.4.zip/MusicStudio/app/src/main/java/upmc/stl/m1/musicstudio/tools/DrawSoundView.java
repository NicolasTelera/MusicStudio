package upmc.stl.m1.musicstudio.tools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by nicolas on 04/03/2015.
 * Cette classe permet de dessiner les sons dans les blocs.
 */
public class DrawSoundView extends View {

    private Paint paint;
    private int center;
    private int[] data;

    public DrawSoundView(Context context, int height, int[] data) {
        super(context);
        this.center = height/2;
        this.data = data;
        this.paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
    }

    @Override
    public void onDraw(Canvas canvas) {

        /* ICI DESSINER DES TRAITS VERTICAUX ENTRE LES POINTS MIN ET MAX PAR PIXEl */
        /*
        int x = 0;
        for(short[] val : this.data) {
            //canvas.drawLine(x, this.center-(val[0]/5), x, this.center+(val[1]/5), this.paint);
            x++;
        }
        */

        int x = 1;
        Point previousUp = new Point(0,0);
        //Point previousDown = new Point(0,0);
        for (int i=0 ; i<this.data.length ; i++) {
            canvas.drawLine(previousUp.x, this.center + previousUp.y, x, this.center + this.data[i], this.paint);
            //canvas.drawLine(previousDown.x, previousDown.y, x, i, this.paint);
            previousUp.x = x;
            previousUp.y = this.data[i];
            //previousDown.x = x;
            //previousDown.y = i;
            x++;
        }

        /*
        int x = 0;
        Point previous = new Point(0, 0);
        for(int i=0 ; i<this.data.length ; i++) {
            canvas.drawLine(previous.x, center+previous.y/5, x, center+(data[i][0]/5), this.paint);
            previous.x = x;
            previous.y = (int)data[i][0];
            x++;
        }
        */
    }

}
