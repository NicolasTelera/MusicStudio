package upmc.stl.m1.musicstudio.activity;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Timer;

import upmc.stl.m1.musicstudio.R;
import upmc.stl.m1.musicstudio.fragment.TrackFragment;
import upmc.stl.m1.musicstudio.tools.PlayBarTask;
import upmc.stl.m1.musicstudio.view.DrawSecondsView;

public class ProjectActivity extends ActionBarActivity implements TrackFragment.OnFragmentInteractionListener {

    private int tracksCount;        // compteur de pistes
    private String projectPath;     // projet courant
    private boolean projectSaved;   // projet sauvegardé
    private boolean changesSaved;   // modifications sauvegardées
    private boolean loaded;
    private ArrayList<TrackFragment> tracks;
    private Timer clock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.prepareLaunch();
        setContentView(R.layout.activity_main);
        this.tracks = new ArrayList<TrackFragment>();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        addSeconds();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch(id) {
            case R.id.action_play_all:
                if (this.clock == null) {
                    this.clock = new Timer();
                    PlayBarTask task = new PlayBarTask(this.tracks);
                    this.clock.scheduleAtFixedRate(task, 0, 12); // 12 = arrondi supérieur donc approximatif...
                }
                return true;
            case R.id.action_pause_all:
                if (this.clock != null) { this.clock.cancel(); this.clock = null; }
                return true;
            case R.id.action_stop_all:
                if (this.clock != null) { this.clock.cancel(); this.clock.purge(); this.clock = null; }
                for (TrackFragment f : this.tracks) f.resetTime();
                return true;
            case R.id.action_new_project:

                this.projectPath = "unnamed";

                // supprimer les infos du projet précédent si il existe
                LinearLayout tracks = (LinearLayout) this.findViewById(R.id.tracks);
                if(tracks.getChildCount() > 0) tracks.removeAllViews();
                if(!projectSaved) {
                    // supprimer les sons
                }
                this.tracks.clear();

                // préparer le nouveau projet
                ((Button) this.findViewById(R.id.button_add_track)).setVisibility(View.VISIBLE);
                this.addTrack(this.findViewById(R.id.tracks));
                return true;

            case R.id.action_open_project:
                return true;
            case R.id.action_save_project:
                return true;
            case R.id.action_export_project:
                return true;
            case R.id.action_quit_app:
                this.finish();
                System.exit(0);
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Fonction d'ajout des secondes à la barre de temps
     */
    public void addSeconds() {
        RelativeLayout timeBar = (RelativeLayout) findViewById(R.id.tracks_time);
        timeBar.addView(new DrawSecondsView(this, timeBar.getHeight(), timeBar.getWidth()));
    }

    /**
     * Initialise un Fragment "TrackFragment" vide et l'ajoute à l'activité.
     * Une piste vide est alors ajoutée à la vue du projet en cours.
     * @param view
     */
    public void addTrack(View view) {

        // on prépare l'id à passer au fragment
        this.tracksCount++;
        Bundle bundle = new Bundle();
        bundle.putInt("id", this.tracksCount);

        // on instancie le fragment
        TrackFragment trackFragment = new TrackFragment();
        trackFragment.setArguments(bundle);
        FragmentManager framgentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = framgentManager.beginTransaction();
        fragmentTransaction.add(R.id.tracks, trackFragment);
        fragmentTransaction.commit();

        // on ajoute le framgnet à la liste des piste du projet
        this.tracks.add(trackFragment);

    }

    /**
     * Permet de communiquer avec les fragments
     * @param uri
     */
    public void onFragmentInteraction(Uri uri) {
        //TODO
    }

    /**********************************************************************************************
     *
     * FONCTIONS DE GESTION DE L'ESPACE DE STOKAGE
     *
     **********************************************************************************************/

    /* Vérifie si le stockage externe est disponible pour l'écriture et la lecture */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    /**
     * Vérifie si l'application peut être lancée.
     * Crée l'espace de stockage s'il n'exise pas déjà.
     */
    public boolean prepareLaunch() {
        if(isExternalStorageWritable()) {
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC + "/MusicStudio");
            path.mkdirs();
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "External Memory Unavailable!", Toast.LENGTH_SHORT);
            toast.show();
            this.finish();
            System.exit(0);
        }
        return true;
    }

}
