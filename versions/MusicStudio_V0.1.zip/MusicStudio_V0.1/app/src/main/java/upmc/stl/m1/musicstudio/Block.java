package upmc.stl.m1.musicstudio;

/**
 * Created by nicolas on 07/02/2015.
 * Bloc permettant de stocker un enregistrement sur une piste.
 * @name : le nom du bloc
 * @start : la position de départ du bloc
 * @length : la durée de l'enregistrement
 */
public class Block {

    private String name;
    private int start;
    private int length;

    public Block(String name, int start, int length) {
        this.name = name;
        this.start = start;
        this.length = length;
    }

    public int getStart() {
        return this.start;
    }

    public int getLength() {
        return this.length;
    }

    public void setStart(int start) {
        this.start = start;
    }

}
