package upmc.stl.m1.musicstudio.fragment;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import upmc.stl.m1.musicstudio.tools.Block;
import upmc.stl.m1.musicstudio.R;
import upmc.stl.m1.musicstudio.task.ConvertToMP4Task;
import upmc.stl.m1.musicstudio.task.PlaySoundTask;
import upmc.stl.m1.musicstudio.task.RecordSoundTask;
import upmc.stl.m1.musicstudio.view.DrawSoundView;
import upmc.stl.m1.musicstudio.tools.Mpeg4Data;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TrackFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TrackFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TrackFragment extends Fragment {

    // Listener de communication entre Activity et Fragment
    private OnFragmentInteractionListener listener;

    // Variables
    private int idTrack;
    private int idSample;
    private String path;
    private long duration;
    private MediaPlayer player;
    private RecordSoundTask recordTask;
    private ConvertToMP4Task convertTask;
    private PlaySoundTask playTask;
    private RelativeLayout barLayout;
    private ArrayList<Block> blocks;
    private HashMap<Block, MediaPlayer> playTasks;
    private int playingSample;

    public static TrackFragment newInstance() {
        TrackFragment fragment = new TrackFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    public TrackFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle params = this.getArguments();
        this.idTrack = params.getInt("idTrack");
        this.path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC +
                "/MusicStudio/track" + this.idTrack + "_sample" + this.idSample).getPath();
        this.blocks = new ArrayList<Block>();
        this.playTasks = new HashMap<Block, MediaPlayer>();
        this.playingSample = -1;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_track, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // LISTENER sur le bouton d'enregistrement
        Button buttonRecord = (Button) getView().findViewById(R.id.track_record_button);
        buttonRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                record(v);
            }
        });

        // LISTENER sur le bouton de lecture
        Button buttonPlay = (Button) getView().findViewById(R.id.track_play_button);
        buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                play();
            }
        });

        // récupération de la barre de temps
        barLayout = (RelativeLayout) getView().findViewById(R.id.play_time_bar);

    }

    public void onButtonPressed(Uri uri) {
        if (listener != null) {
            listener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    /**********************************************************************************************
     *
     * INTERFACES DE COMMUNICATION
     *
     **********************************************************************************************/

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        public void onFragmentInteraction(Uri uri);
    }

    /**
     * Nécessaire pour attendre la fin de la tâche asynchrone de conversion avant
     * de dessiner le bloc sur la piste.
     */
    public interface FragmentCallback {
        public void onTaskDone();
    }

    /**********************************************************************************************
     *
     * FONCTIONS DE MANIPULATION DE LA PISTE
     *
     **********************************************************************************************/

    /**
     * Enregistre un son.
     * @param view
     */
    public void record(View view) {

        Button recordButton = (Button) getView().findViewById(R.id.track_record_button);

        if(this.recordTask == null || this.recordTask.getStatus() == AsyncTask.Status.FINISHED) {
            // Lancement de l'enregistrement
            this.recordTask = new RecordSoundTask(this, this.path);
            this.recordTask.execute();
            recordButton.setText("STOP");
            // lancement de l'enregistrement
            this.duration = System.nanoTime();
        } else {
            this.duration = System.nanoTime() - this.duration;
            System.out.println("duréé de la prise : " + (duration/1E9));
            // Fin de l'enregistrement
            this.recordTask.setIsRecording(false);
            recordButton.setText("RECORD");
            // Lancement de la tâche de conversion
            this.convertTask = new ConvertToMP4Task(this, this.path, new FragmentCallback() {
                @Override
                public void onTaskDone() {
                    // Préparation du block
                    Block block = new Block(idSample, "sample" + idSample, 0, (int)duration);
                    addBlock(block);
                    idSample++;
                }
            });
            convertTask.execute();
        }

    }

    /**
     * Lit un son préalablement enregistré.
     */
    public void play() {

        Button recordButton = (Button) getView().findViewById(R.id.track_play_button);

        if(this.playTask == null || this.player == null) {
            this.player = new MediaPlayer();
            this.playTask = new PlaySoundTask(this, this.path, this.player);
            this.playTask.execute();
            recordButton.setText("STOP");
        } else {
            this.player.stop();
            this.player.release();
            this.playTask = null;
            recordButton.setText("PLAY");
        }

    }

    /**
     * Ajout d'un bloc sur une piste
     * @param block
     */
    public void addBlock(final Block block) {

        // préparation d'un LinearLayout pour représenter le bloc
        RelativeLayout layoutBlock = new RelativeLayout(getActivity());
        layoutBlock.setBackgroundColor(0xfffffd11);

        // ajout d'un listener sur les mouvements du doigt pour déplacer le bloc        /!\ TRAVAILLER SUR LE DEPLACEMENT PLUS PRECIS
        layoutBlock.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) v.getLayoutParams();
                    RelativeLayout track = (RelativeLayout) v.getParent();
                    int center = params.width / 2;
                    float position = event.getX() + v.getX() - center;
                    if (position < 0) position = track.getX();
                    params.setMargins((int) position, 0, 0, 0);
                    v.setLayoutParams(params);
                    block.setStart((int)position);
                    //if (block.getId() == playingSample) ICI METTRE A JOUR LE LECTEUR ASSOCIE
                }
                return true;
            }
        });

        // ajout du block à la piste
        RelativeLayout piste = (RelativeLayout) getView().findViewById(R.id.track_sound_block);
        piste.addView(layoutBlock);

        // enregistrement du bloc dans la table de hachage
        String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC +
                "/MusicStudio/track" + this.idTrack + "_" + block.getName() + ".mp4").getPath();
        //PlaySoundTask task = new PlaySoundTask(this, path, new MediaPlayer());
        //this.playTasks.put(block, task);
        MediaPlayer player = new MediaPlayer();
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                playingSample = -1;
            }
        });
        try {
            player.setDataSource(path);
            player.prepare();
        } catch (IOException e) { e.printStackTrace(); }
        this.blocks.add(block);
        this.playTasks.put(block, player);

        // représentation du son dans le bloc généré
        this.drawSound(layoutBlock);

    }

    /**
     * Mettre en pause la lecture de la piste
     */
    public void pausePlaying() {
        for (MediaPlayer mp : this.playTasks.values()) {
            mp.pause();
            System.out.println("stopped at : " + mp.getCurrentPosition());
        }
    }

    /**
     * Relancer la lecture arpès la pause
     */
    public void resumePlaying() {
        if (this.playingSample != -1) {
            for (Block b : this.playTasks.keySet()) {
                if (b.getId() == this.playingSample) {
                    this.playTasks.get(b).start();
                }
            }
        }
    }

    /**
     * Arrêter la lecure de la piste
     */
    public void stopPlaying() {
        for (MediaPlayer mp : this.playTasks.values()) {
            mp.pause();
            mp.seekTo(0);
            // ne pas utiliser mp.stop(); qui empêche de lire derrière
        }
        barLayout.setX(0);
    }

    /**********************************************************************************************
     *
     * FONCTIONS DE VISUALISATION
     *
     **********************************************************************************************/

    /**
     * Dessin de la forme d'un son
     * @param layoutBloc
     */
    public void drawSound(RelativeLayout layoutBloc) {

        // récupération du bloc à dessiner
        RelativeLayout piste = (RelativeLayout) getView().findViewById(R.id.track_sound_block);

        // traitement du fichier MPEG-4
        Mpeg4Data mpeg4Data = new Mpeg4Data(this.path + ".mp4");
        short[] data = mpeg4Data.computeDataToDraw();

        // lancement du dessin de la forme d'onde
        Bitmap bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        DrawSoundView view = new DrawSoundView(getActivity(), piste.getHeight(), data);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((data.length-5)*2, ViewGroup.LayoutParams.MATCH_PARENT);
        layoutBloc.setLayoutParams(params);
        layoutBloc.addView(view);
        RelativeLayout bar = (RelativeLayout) getView().findViewById(R.id.play_time_bar);

        // on remet la barre de lecture au premier plan
        bar.bringToFront();
    }

    /**
     * Affichage de la barre de temps
     */
    public void drawTimeAndPlay() {
        String path;
        for (Block b : this.blocks) {
            if (b.getStart() == barLayout.getX()) {
                this.playTasks.get(b).start();
                this.playingSample = b.getId();
            }
        }
        barLayout.setX(barLayout.getX()+1f);
    }

}
