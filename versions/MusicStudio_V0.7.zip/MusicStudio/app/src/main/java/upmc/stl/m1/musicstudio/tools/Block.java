package upmc.stl.m1.musicstudio.tools;

/**
 * Created by nicolas on 07/02/2015.
 * Bloc permettant de stocker un enregistrement sur une piste.
 * @name : le nom du bloc
 * @start : la position de départ du bloc
 * @length : la durée de l'enregistrement
 */
public class Block {

    private int id;
    private String name;
    private int start;
    private int length;

    public Block(int id, String name, int start, int length) {
        this.id = id;
        this.name = name;
        this.start = start;
        this.length = length;
    }

    public int getId() {
        return this.id;
    }

    public String getName() { return this.name; }

    public int getStart() {
        return this.start;
    }

    public int getLength() {
        return this.length;
    }

    public void setStart(int start) {
        this.start = start;
    }



}
