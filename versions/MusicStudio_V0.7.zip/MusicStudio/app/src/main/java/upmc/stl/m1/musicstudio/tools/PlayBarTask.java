package upmc.stl.m1.musicstudio.tools;

import java.util.ArrayList;

import upmc.stl.m1.musicstudio.fragment.TrackFragment;

/**
 * Created by nicolas on 30/04/2015.
 */
public class PlayBarTask extends java.util.TimerTask {

    private ArrayList<TrackFragment> tracks;

    public PlayBarTask(ArrayList<TrackFragment> tracks) {
        this.tracks = tracks;
    }

    @Override
    public void run() {
        for (TrackFragment f : this.tracks) {
            f.drawTimeAndPlay();
        }
    }

}
