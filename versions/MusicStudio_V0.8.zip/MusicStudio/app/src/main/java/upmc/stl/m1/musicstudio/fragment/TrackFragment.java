package upmc.stl.m1.musicstudio.fragment;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.Switch;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import upmc.stl.m1.musicstudio.tools.Block;
import upmc.stl.m1.musicstudio.R;
import upmc.stl.m1.musicstudio.task.ConvertToMP4Task;
import upmc.stl.m1.musicstudio.task.PlaySoundTask;
import upmc.stl.m1.musicstudio.task.RecordSoundTask;
import upmc.stl.m1.musicstudio.view.DrawSoundView;
import upmc.stl.m1.musicstudio.tools.Mpeg4Data;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TrackFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TrackFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TrackFragment extends Fragment {

    // Listener de communication entre Activity et Fragment
    private OnFragmentInteractionListener listener;

    // Variables
    private int idTrack;
    private int idSample;
    private String path;
    private long duration;
    private float timeIndex;
    private boolean moving;
    private RecordSoundTask recordTask;
    private ConvertToMP4Task convertTask;
    private RelativeLayout barLayout;
    private ArrayList<Block> blocks;
    private HashMap<Block, MediaPlayer> playTasks;
    private int playingSample;

    public static TrackFragment newInstance() {
        TrackFragment fragment = new TrackFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    public TrackFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle params = this.getArguments();
        this.idTrack = params.getInt("idTrack");
        this.timeIndex = params.getFloat("timeIndex");
        this.idSample = 1;
        this.path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC +
                "/MusicStudio/track" + this.idTrack + "_sample").getPath();
        this.blocks = new ArrayList<Block>();
        this.playTasks = new HashMap<Block, MediaPlayer>();
        this.playingSample = -1;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_track, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // LISTENER sur le bouton d'enregistrement
        Button buttonRecord = (Button) getView().findViewById(R.id.track_record_button);
        buttonRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                record(v);
            }
        });

        // LISTENER sur le switch de mute
        Switch muteSwitch = (Switch) getView().findViewById(R.id.track_mute_switch);
        muteSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mute(isChecked);
            }
        });

        // récupération de la barre de temps
        barLayout = (RelativeLayout) getView().findViewById(R.id.play_time_bar);
        this.barLayout.setX(this.timeIndex);

    }

    public void onButtonPressed(Uri uri) {
        if (listener != null) {
            listener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    /**********************************************************************************************
     *
     * ACCESSEURS ET MODIFICATEURS
     *
     **********************************************************************************************/

    public float getTimeIndex() {
        return this.timeIndex;
    }

    /**********************************************************************************************
     *
     * INTERFACES DE COMMUNICATION
     *
     **********************************************************************************************/

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        public void onFragmentInteraction(Uri uri);
    }

    /**
     * Nécessaire pour attendre la fin de la tâche asynchrone de conversion avant
     * de dessiner le bloc sur la piste.
     */
    public interface FragmentCallback {
        public void onTaskDone();
    }

    /**********************************************************************************************
     *
     * FONCTIONS DE MANIPULATION DE LA PISTE
     *
     **********************************************************************************************/

    /**
     * Enregistre un son.
     * @param view
     */
    public void record(View view) {

        Button recordButton = (Button) getView().findViewById(R.id.track_record_button);

        if(this.recordTask == null || this.recordTask.getStatus() == AsyncTask.Status.FINISHED) {
            // Lancement de l'enregistrement
            this.recordTask = new RecordSoundTask(this, this.path + this.idSample);
            this.recordTask.execute();
            recordButton.setText("STOP");
            // lancement de l'enregistrement
            this.duration = System.nanoTime();
        } else {
            this.duration = System.nanoTime() - this.duration;
            //System.out.println("duréé de la prise : " + (duration/1E9));
            // Fin de l'enregistrement
            this.recordTask.setIsRecording(false);
            recordButton.setText("RECORD");
            // Lancement de la tâche de conversion
            this.convertTask = new ConvertToMP4Task(this, this.path + this.idSample, new FragmentCallback() {
                @Override
                public void onTaskDone() {
                    // Préparation du block
                    Block block = new Block(idSample, "sample" + idSample, 0, (int)duration);
                    addBlock(block);
                }
            });
            convertTask.execute();
        }

    }

    /**
     * Fonction de mute
     */
    public void mute(boolean isChecked) {
        if (isChecked) {
            for (MediaPlayer mp : this.playTasks.values()) {
                mp.setVolume(0.0f, 0.0f);
            }
        } else {
            for (MediaPlayer mp : this.playTasks.values()) {
                mp.setVolume(1.0f, 1.0f);
            }
        }
    }

    /**
     * Ajout d'un bloc sur une piste
     * @param block
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN) // nécessaire car l'API à 18 n'est pas détectée...
    public void addBlock(final Block block) {

        // préparation d'un LinearLayout pour représenter le bloc
        final RelativeLayout layoutBlock = new RelativeLayout(getActivity());
        //layoutBlock.setBackgroundColor(0xfffffd11);
        layoutBlock.setBackground(getResources().getDrawable(R.drawable.custom_border_block));

        // ajout d'un listener sur les mouvements du doigt pour déplacer le bloc        /!\ TRAVAILLER SUR LE DEPLACEMENT PLUS PRECIS
        layoutBlock.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    // on empêche le long click (et on suprpime la vibration associée)
                    moving = true;
                    v.setHapticFeedbackEnabled(false);
                    RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) v.getLayoutParams();
                    RelativeLayout track = (RelativeLayout) v.getParent();
                    int center = params.width / 2;
                    float position = event.getX() + v.getX() - center;
                    if (position < 0) position = track.getX();
                    params.setMargins((int) position, 0, 0, 0);
                    v.setLayoutParams(params);
                    block.setStart((int) position);
                    //if (block.getId() == playingSample) ICI METTRE A JOUR LE LECTEUR ASSOCIE
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    // on rend le long click possible à nouveau (et la vibration associée)
                    moving = false;
                    v.setHapticFeedbackEnabled(true);
                }
                return false;
            }
        });

        // ajout d'un listener sur l'appui prolongé pour les options
        layoutBlock.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (!moving) {
                    PopupMenu popupMenu = new PopupMenu(getActivity(), layoutBlock);
                    popupMenu.getMenuInflater().inflate(R.menu.menu_popup_block, popupMenu.getMenu());
                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            switch (item.getTitle().toString()) {
                                case "Duplicate":
                                    duplicateBloc(block, layoutBlock);
                                    break;
                                case "Copy":
                                    break;
                                case "Delete":
                                    deleteBlock(block, layoutBlock);
                                    break;
                                default:
                                    break;
                            }
                            return true;
                        }
                    });
                    popupMenu.show();
                }
                return true;
            }
        });


        // ajout du block à la piste
        RelativeLayout piste = (RelativeLayout) getView().findViewById(R.id.track_sound_block);
        piste.addView(layoutBlock);

        // enregistrement du bloc dans la table de hachage
        //PlaySoundTask task = new PlaySoundTask(this, path, new MediaPlayer());
        //this.playTasks.put(block, task);
        MediaPlayer player = new MediaPlayer();
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                playingSample = -1;
            }
        });
        try {
            player.setDataSource(this.path + this.idSample + ".mp4");
            player.prepare();
        } catch (IOException e) { e.printStackTrace(); }
        this.blocks.add(block);
        this.playTasks.put(block, player);

        // représentation du son dans le bloc généré
        this.drawSound(layoutBlock);
    }

    /**
     * Duplication d'un bloc
     */
    public void duplicateBloc(Block block, RelativeLayout layoutBlock) {

        // copie création du nouveau fichier audio
        try {
            byte[] buf = new byte[1024];
            int len;
            InputStream in = new FileInputStream(this.path + block.getId() + ".raw");
            OutputStream out = new FileOutputStream(this.path + (this.idSample+1) + ".raw");
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in = new FileInputStream(this.path + block.getId() + ".mp4");
            out = new FileOutputStream(this.path + (this.idSample+1) + ".mp4");
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in.close();
            out.close();
        }
        catch (FileNotFoundException e) { e.printStackTrace(); }
        catch (IOException e) { e.printStackTrace(); }

        // copie du block
        Block newBlock = new Block();
        newBlock.setId(++this.idSample);
        newBlock.setName("sample" + this.idSample);
        newBlock.setStart(block.getStart()+block.getLength()+1);
        newBlock.setLength(block.getLength());
        this.addBlock(newBlock);
    }

    /**
     * Suppression d'un bloc
     */
    public void deleteBlock(Block block, RelativeLayout layoutBlock) {
        // suppression du bloc enregistré
        this.blocks.remove(block);
        this.playTasks.remove(block);
        if (block.getId() == this.playingSample) this.playingSample = -1;
        // suppression du layout du bloc
        RelativeLayout track = (RelativeLayout) getView().findViewById(R.id.track_sound_block);
        track.removeView(layoutBlock);
    }

    /**
     * Mettre en pause la lecture de la piste
     */
    public void pausePlaying() {
        for (MediaPlayer mp : this.playTasks.values()) {
            mp.pause();
        }
    }

    /**
     * Relancer la lecture arpès la pause
     */
    public void resumePlaying() {
        if (this.playingSample != -1) {
            for (Block b : this.playTasks.keySet()) {
                if (b.getId() == this.playingSample) {
                    this.playTasks.get(b).start();
                }
            }
        }
    }

    /**
     * Arrêter la lecure de la piste
     */
    public void stopPlaying() {
        if (this.playingSample != -1) {
            for (MediaPlayer mp : this.playTasks.values()) {
                mp.pause();
                mp.seekTo(0);
                // ne pas utiliser mp.stop(); qui empêche de lire derrière
            }
        }
        this.barLayout.setX(0);
        this.timeIndex = 0;

    }

    /**********************************************************************************************
     *
     * FONCTIONS DE VISUALISATION
     *
     **********************************************************************************************/

    /**
     * Dessin de la forme d'un son
     * @param layoutBloc
     */
    public void drawSound(RelativeLayout layoutBloc) {

        // récupération du bloc à dessiner
        RelativeLayout piste = (RelativeLayout) getView().findViewById(R.id.track_sound_block);

        // traitement du fichier MPEG-4
        Mpeg4Data mpeg4Data = new Mpeg4Data(this.path + this.idSample + ".mp4");
        short[] data = mpeg4Data.computeDataToDraw();

        // lancement du dessin de la forme d'onde
        Bitmap bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        DrawSoundView view = new DrawSoundView(getActivity(), piste.getHeight(), data);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((data.length-5)*2, ViewGroup.LayoutParams.MATCH_PARENT);
        layoutBloc.setLayoutParams(params);
        layoutBloc.addView(view);
        RelativeLayout bar = (RelativeLayout) getView().findViewById(R.id.play_time_bar);

        // on remet la barre de lecture au premier plan
        bar.bringToFront();

        // on incrémente le compteur de sample
        this.idSample++;
    }

    /**
     * Affichage de la barre de temps
     */
    public void drawTimeAndPlay() {
        this.timeIndex++;
        if (this.blocks != null && this.barLayout != null) {
            for (Block b : this.blocks) {
                if (b.getStart() == this.timeIndex-1) {
                    this.playTasks.get(b).start();
                    this.playingSample = b.getId();
                }
            }
            this.barLayout.setX(this.timeIndex);
        }
    }

}




/* FONCTION PLUS NECESSAIRE


    // LISTENER sur le bouton de lecture
        Button buttonPlay = (Button) getView().findViewById(R.id.track_play_button);
        buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                play();
            }
        });


    public void play() {

        Button recordButton = (Button) getView().findViewById(R.id.track_play_button);

        if(this.playTask == null || this.player == null) {
            this.player = new MediaPlayer();
            this.playTask = new PlaySoundTask(this, this.path, this.player);
            this.playTask.execute();
            recordButton.setText("STOP");
        } else {
            this.player.stop();
            this.player.release();
            this.playTask = null;
            recordButton.setText("PLAY");
        }

    }
*/