package upmc.stl.m1.musicstudio.tools;

/**
 * Classe de stockage d'un atome provenant d'un fichier MPEG4-v2
 * Created by nicolas on 25/03/2015.
 */
public class Atom {

    private String name;
    private int index;
    private int size;
    private byte[] data;

    public Atom(int index) {
        this.index = index;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSize(int size) {
        this.size = size;
        this.data = new byte[size];
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public byte[] getData() {
        return data;
    }

    public int getSize() {
        return size;
    }

    @Override
    public String toString() {
        return "Atome '" + this.name + "' à l'index " + this.index + " de taille " + this.size;
    }

    /*
    public Atom findChildByName(int position, String name) {

        byte[] temp = new byte[4];
        StringBuilder builder = new StringBuilder();
        boolean done = false;

        try {

            do {

                builder = new StringBuilder();

                // récupération du nom de l'atome
                temp = new byte[4];
                for (int i=0 ; i<4 ; i++) temp[i] = this.data[position + 4 + i];
                name = new String(temp, "UTF-8");

                System.out.println(name);
                if(name.equals("stco")) {
                    // RENSEIGNER START ET NBCHUNKS
                    done = true;
                } else {

                    // this.getMdatInfos()

                    // récupération de la longueur de l'atome
                    for (int i = 0; i < 4; i++)
                        builder.append(String.format("%02x", data[index + i]));
                    position += Integer.parseInt(builder.toString(), 16);
                    //}

                    if (position >= this.size) done = true;
                }

            } while (!done);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return null;
    }
    */

}
