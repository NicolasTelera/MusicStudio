package upmc.stl.m1.musicstudio.tools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.View;

/**
 * Created by nicolas on 04/03/2015.
 * Cette classe permet de dessiner les sons dans les blocs.
 */
public class DrawSoundView extends View {

    private Paint paint;
    private int center;
    private byte[] data;

    public DrawSoundView(Context context, int height, byte[] data) {
        super(context);
        this.center = height/2;
        this.data = data;
        this.paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
    }

    @Override
    public void onDraw(Canvas canvas) {

        if(this.data != null) {

            int x = 0;
            Point previous = new Point(0, 0);
            for(int i=0 ; i<this.data.length ; i++) {
                canvas.drawLine(previous.x, center+previous.y, x, center+((int)data[i]), this.paint);
                previous.x = x;
                previous.y = (int)data[i];
                x++;
            }

            /*
            ArrayList<Integer> moyennes = new ArrayList<Integer>();
            int moyenne = 0;

            for(int i=0 ; i<this.data.length ; i=i+10) {
                for(int j=i ; j<10 ; j++) {
                    moyenne += (int)this.data[j];
                }
                moyenne = moyenne / 10;
                moyennes.add(moyenne);
                moyenne = 0;
            }

            int x = 0;
            Point previous = new Point(0, this.center);
            for(Integer m : moyennes) {
                canvas.drawLine(previous.x, previous.y, x, m, this.paint);
                previous.x = x;
                previous.y = m;
                x++;
            }
            */

        }
    }

}
