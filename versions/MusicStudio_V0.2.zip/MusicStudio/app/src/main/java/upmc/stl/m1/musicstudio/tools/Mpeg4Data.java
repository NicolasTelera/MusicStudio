package upmc.stl.m1.musicstudio.tools;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/**
 * Classe de stockage des données relatives à un fichier MPEG4-v2.
 * Created by nicolas on 25/03/2015.
 */
public class Mpeg4Data {

    private ArrayList<Atom> atoms;
    private byte[] totalData;
    private byte[] rawData;
    private int nbChunks;
    private int startIndex;

    public Mpeg4Data(byte[] data) {
        this.totalData = data;
        this.atoms = new ArrayList<Atom>();
        this.rawData = new byte[0];
    }

    public ArrayList<Atom> getAtoms() {
        return this.atoms;
    }

    public byte[] getRawData() {
        return rawData;
    }

    public void addAtom(Atom atom) {
        this.atoms.add(atom);
    }

    public Atom getAtomByName(String name) {
        for(Atom a : this.atoms) {
            // Atom stco = this.getAtomByName("stco");
            // if(a.findChildByName(0, name) != null) return a;
        }
        return null;
    }

    public void findMdatInfos() {

        byte[] data = this.atoms.get(1).getData();
        byte[] temp = new byte[4];
        StringBuilder builder = new StringBuilder();
        boolean done = false;
        int index = 8;
        int size = 0;
        String name = "";

        try {

            // parsing complet du fichier pour récupérer les 4 atomes principaux
            do {

                builder = new StringBuilder();
                Atom atom = new Atom(index);

                // récupération du nom de l'atome
                temp = new byte[4];
                for (int i=0 ; i<4 ; i++) temp[i] = data[index + i + 4];
                name = new String(temp, "UTF-8");

                // si on est sur l'atome voulu, on descend d'un niveau
                // sinon on continue le traitement
                if (name.equals("trak")) index += 8;
                else if (name.equals("mdia")) index += 8;
                else if (name.equals("minf")) index += 8;
                else if (name.equals("stbl")) index += 8;
                else {

                    // récupération de la longueur de l'atome
                    for (int i=0 ; i<4 ; i++) builder.append(String.format("%02x", data[index + i]));
                    size = Integer.parseInt(builder.toString(), 16);

                    // si on est sur l'atome rechercher, on traite les informations
                    if (name.equals("stco")) {

                        // on récupère le nombre d'entrées
                        index += 12;
                        builder = new StringBuilder();
                        for (int i = 0; i < 4; i++) builder.append(String.format("%02x", data[index + i]));
                        this.nbChunks = Integer.parseInt(builder.toString(), 16);

                        // on récupère la position de départ des raw data
                        index += 4;
                        builder = new StringBuilder();
                        for (int i = 0; i < (size - 16); i++) builder.append(String.format("%02x", data[index + i]));
                        this.startIndex = Integer.parseInt(builder.toString(), 16);
                        this.rawData = new byte[this.totalData.length - this.startIndex];
                        this.fillRawData();

                        done = true;

                    }

                    if((index += size) >= data.length) done = true;

                }

            } while(!done);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }

    public void fillRawData() {

        for (int i=0 ; i<this.rawData.length ; i++)
            this.rawData[i] = this.totalData[this.startIndex + i];


        /**
         * PARTIE EXPERIMENTATION SUR LA CREATION DU TABLEAU DE DONNEES A REPRESENTER
         */

    }

}
