package upmc.stl.m1.musicstudio.task;

import android.os.AsyncTask;
import android.os.Environment;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Tâche asynchrone de mixage des piste du projet ensembles.
 */
public class MixSoundsTask extends AsyncTask <Void, Void, Void> {

    public MixSoundsTask() {}

    @Override
    protected Void doInBackground(Void... params) {

        try {

            String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC + "/MusicStudio").getPath();

            InputStream is1 = new FileInputStream(path + "/sample1.raw");
            InputStream is2 = new FileInputStream(path + "/sample2.raw");

            short[] music1Array = bytetoshort(convertStreamToByteArray(is1));
            short[] music2Array = bytetoshort(convertStreamToByteArray(is2));

            short[] output = new short[music1Array.length];
            for(int i=0; i < output.length; i++){

                float samplef1 = music1Array[i] / 32768.0f;
                float samplef2 = music2Array[i] / 32768.0f;

                float mixed = samplef1 + samplef2;
                // reduce the volume a bit:
                mixed *= 0.8;
                // hard clipping
                if (mixed > 1.0f) mixed = 1.0f;
                if (mixed < -1.0f) mixed = -1.0f;
                short outputSample = (short)(mixed * 32768.0f);

                output[i] = outputSample;
            }
            //sauvegarder le fichier
            /*File outputFile = new File(path + "/mix.mp4");
            if (outputFile.exists()) outputFile.delete();*/

            int bufferSize = 32 * 1024;
            DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(
                new FileOutputStream(path+"/mix.mp4"), bufferSize)
            );
            try {
                for (int i = 0; i < output.length; i++) {
                    dos.writeShort(output[i]);
                    System.out.println(i);
                }
            } finally {
                dos.close();
            }
            System.out.println("FINI");

            /*ByteBuffer myByteBuffer = ByteBuffer.allocate(20);
            myByteBuffer.order(ByteOrder.LITTLE_ENDIAN);

            ShortBuffer myShortBuffer = myByteBuffer.asShortBuffer();
            myShortBuffer.put(output);

            FileChannel out = new FileOutputStream(outputFile).getChannel();
            out.write(myByteBuffer);
            out.close();*/
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    public short[] bytetoshort(byte[]bite){
    // Grab size of the byte array, create an array of shorts of the same size
        int size = bite.length;
        short[] shortArray = new short[size];

        for (int index = 0; index < size; index++)
            shortArray[index] = (short) bite[index];

        return shortArray;

    }


    public byte[] convertStreamToByteArray(InputStream is) throws IOException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buff = new byte[10240];
        int i = Integer.MAX_VALUE;
        while ((i = is.read(buff, 0, buff.length)) > 0) {
            baos.write(buff, 0, i);
        }

        return baos.toByteArray(); // be sure to close InputStream in calling function

    }

    /*

    @Override
    protected Void doInBackground(Void... params) {
        try {
            String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC + "/MusicStudio").getPath();
            File outputFile = new File(path + "/mix.mp4");
            if (outputFile.exists()) outputFile.delete();

            File file = new File(path + "/sample1.raw");
            short[] music1Array = sampleToShortArray(file, false);
            file = new File(path + "/sample2.raw");
            short[] music2Array = sampleToShortArray(file, false);

            short[] output = new short[music1Array.length];
            for(int i=0; i < output.length; i++){

                float samplef1 = music1Array[i] / 32768.0f;
                float samplef2 = music2Array[i] / 32768.0f;

                float mixed = samplef1 + samplef2;
                // reduce the volume a bit:
                mixed *= 0.8;
                // hard clipping
                if (mixed > 1.0f) mixed = 1.0f;
                if (mixed < -1.0f) mixed = -1.0f;
                short outputSample = (short)(mixed * 32768.0f);


                output[i] = outputSample;
            }
            ByteBuffer myByteBuffer = ByteBuffer.allocate(20);
            myByteBuffer.order(ByteOrder.LITTLE_ENDIAN);

            ShortBuffer myShortBuffer = myByteBuffer.asShortBuffer();
            myShortBuffer.put(output);

            FileChannel out = new FileOutputStream(outputFile).getChannel();
            out.write(myByteBuffer);
            out.close();
        } catch (Resources.NotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    private static short swapBytes(byte byte0, byte byte1){
        return (short)((byte1 & 0xff) << 8 | (byte0 & 0xff));
    }

    public static byte[] sampleToByteArray(File sample, boolean swap) {
        byte[] outputByteArray = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BufferedInputStream bis = null;
            bis = new BufferedInputStream(new FileInputStream(sample));

            int BUFFERSIZE = 4096;
            byte[] buffer = new byte[BUFFERSIZE];
            while(bis.read(buffer) != - 1){
                baos.write(buffer);
            }
            outputByteArray = baos.toByteArray();
            bis.close();
            baos.close();

            if(swap){
                for(int i=0; i < outputByteArray.length - 1; i=i+2){
                    byte byte0 = outputByteArray[i];
                    outputByteArray[i] = outputByteArray[i+1];
                    outputByteArray[i+1] = byte0;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return outputByteArray;
    }

    public static short[] sampleToShortArray(File sample, boolean swap) {
        short[] outputArray = new short[(int) sample.length() / 2];
        byte[] outputByteArray = sampleToByteArray(sample, false);

        for (int i = 0, j = 0; i < outputByteArray.length; i += 2, j++) {
            if (swap) {
                outputArray[j] = swapBytes(outputByteArray[i], outputByteArray[i + 1]);
            } else {
                outputArray[j] = swapBytes(outputByteArray[i + 1], outputByteArray[i]);
            }
        }
        return outputArray;
    }

    */

}
