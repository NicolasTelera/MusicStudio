package upmc.stl.m1.musicstudio.task;

import android.app.Fragment;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.widget.Button;

import java.io.IOException;

import upmc.stl.m1.musicstudio.R;

/**
 * Tâche asynchrone de lecture d'un son.
 */
public class PlaySoundTask extends AsyncTask<Void, Void, Void> {

    private Fragment context;
    private String path;
    private MediaPlayer player;

    public PlaySoundTask(Fragment context, String path, MediaPlayer player) {
        this.context = context;
        this.path = path + ".mp4";
        this.player = player;
        try {
            this.player.setDataSource(this.path);
            this.player.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected Void doInBackground(Void... params) {

        /*
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Button recordButton = (Button) context.getView().findViewById(R.id.track_play_button);
                recordButton.setText("PLAY");
            }
        });
        */
        this.player.start();
        return null;
    }

}






/*
private final int FREQUENCY = 44100;
private final int CHANNEL_CONFIGURATION = AudioFormat.CHANNEL_OUT_MONO;
private final int AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
private final int AUDIO_STREAM = AudioManager.STREAM_MUSIC;
private final int AUDIO_MODE = AudioTrack.MODE_STREAM;
//private AudioTrack audioTrack;


        File file = new File(this.path.getPath());

        int bufferSize = (int)file.length();
        short[] buffer = new short[bufferSize];

        try {

            InputStream is = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(is);
            DataInputStream dis = new DataInputStream(bis);

            int i = 0;
            while(dis.available() > 0) {
                buffer[i] = dis.readShort();
                i++;
            }
            dis.close();

            AudioTrack audioTrack = new AudioTrack(AUDIO_STREAM, FREQUENCY, CHANNEL_CONFIGURATION, AUDIO_ENCODING, bufferSize, AUDIO_MODE);
            System.out.println(audioTrack.getState());

            audioTrack.playAll();
            audioTrack.write(buffer, 0, bufferSize);

            audioTrack.stop();
            audioTrack.release();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

*/