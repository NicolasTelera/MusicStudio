package upmc.stl.m1.musicstudio.tools;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/**
 * Classe de stockage des données relatives à un fichier MPEG4-v2.
 * Created by nicolas on 25/03/2015.
 */
public class Mpeg4Data {

    private ArrayList<Atom> atoms;
    private ArrayList<Chunk> chunks;
    private ArrayList<Integer> byteCountBySample; // stockage des taille des samples en bytes (samples dans l'ordre)
    private int sizeRawData;                      // (ArrayList car on doit la remplir avant de savoir sa taille)
    private byte[] totalData;

    public Mpeg4Data(byte[] data) {
        this.totalData = data;
        this.atoms = new ArrayList<Atom>();
        this.chunks = new ArrayList<Chunk>();
        this.byteCountBySample = new ArrayList<Integer>();
    }

    public ArrayList<Atom> getAtoms() {
        return this.atoms;
    }

    public void addAtom(Atom atom) {
        this.atoms.add(atom);
    }

    public Atom getAtomByName(String name) {
        for(Atom a : this.atoms)
            if(a.getName().equals(name)) return a;
        return null;
    }

    public void findMoovInfos() {

        byte[] data = this.getAtomByName("moov").getData();
        byte[] temp = new byte[4];
        StringBuilder builder = null;
        boolean done = false;
        int index = 8;
        int size = 0;
        String name = "";

        int[] exec = new int[3]; // stocker les index des atomes pour ensuite les parser dans l'ordre voulu (stsc, stco, stsz)

        try {

            // parsing complet du fichier pour récupérer les 4 atomes principaux
            do {

                builder = new StringBuilder();
                Atom atom = new Atom(index);

                // récupération du nom de l'atome
                temp = new byte[4];
                for (int i=0 ; i<4 ; i++) temp[i] = data[index + i + 4];
                name = new String(temp, "UTF-8");

                // si on est sur l'atome voulu, on descend d'un niveau
                // sinon on continue le traitement
                if (name.equals("trak")) index += 8;
                else if (name.equals("mdia")) index += 8;
                else if (name.equals("minf")) index += 8;
                else if (name.equals("stbl")) index += 8;
                else {



                    // récupération de la longueur de l'atome
                    for (int i=0 ; i<4 ; i++) builder.append(String.format("%02x", data[index + i]));
                    size = Integer.parseInt(builder.toString(), 16);

                    // parsing des atomes recherchés
                    if (name.equals("stsc")) exec[0] = index;
                    else if (name.equals("stco")) exec[1] = index;
                    else if (name.equals("stsz")) exec[2] = index;

                    // vérification de la condition de sortie
                    if((index += size) >= data.length) done = true;

                }

            } while(!done);

            this.parseAtomByName("stsc", exec[0]);
            this.parseAtomByName("stco", exec[1]);
            this.parseAtomByName("stsz", exec[2]);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        int cpt = 0;
        for(Chunk c : this.chunks) {
            System.out.println(c);
            for (int i=0 ; i<c.getSamplesPerChunk() ; i++) {
                //System.out.println("- sample n°" + cpt +  " : " + this.byteCountBySample.get(cpt) + " bytes");
                cpt++;
            }
        }

    }

    public void parseAtomByName(String name, int index) {

        byte[] data = this.getAtomByName("moov").getData();
        StringBuilder builder = new StringBuilder();
        int size = 0;
        int cpt = 0;

        // récupération de la longueur de l'atome
        for (int i=0 ; i<4 ; i++) builder.append(String.format("%02x", data[index + i]));
        size = Integer.parseInt(builder.toString(), 16);

        switch(name) {


            case "stsc" : /* -- récupération du nombre de samples par chunk -- */

                System.out.println("taille stsc : " + size);

                index += 16;
                builder = new StringBuilder();
                for (int i=0 ; i<size-16 ; i += 12) {
                    Chunk chunk = new Chunk();
                    StringBuilder numBuilder = new StringBuilder();
                    StringBuilder countBuilder = new StringBuilder();
                    StringBuilder descBuilder = new StringBuilder();
                    for (int j = 0; j < 4; j++) {
                        numBuilder.append(String.format("%02x", data[index + i + j]));
                        countBuilder.append(String.format("%02x", data[index + i + j + 4]));
                        descBuilder.append(String.format("%02x", data[index + i + j + 8]));
                    }
                    chunk.setNum(Integer.parseInt(numBuilder.toString(), 16));
                    chunk.setSamplesPerChunk(Integer.parseInt(countBuilder.toString(), 16));
                    chunk.setSampleDescIndex(Integer.parseInt(descBuilder.toString(), 16));
                    this.chunks.add(chunk);
                }

                break;

            case "stco" : /* -- récupération de l'offset (sur les données totales) des chunks - */

                index += 16;
                builder = new StringBuilder();

                for (int i=0 ; i<size-16 ; i += 4) {
                    builder = new StringBuilder();
                    for (int j = 0; j < 4; j++)
                        builder.append(String.format("%02x", data[index + i + j]));
                    this.chunks.get(cpt).setOffset(Integer.parseInt(builder.toString(), 16));
                    cpt++;
                }

                break;

            case "stsz" : /* -- récupération de la taille de chaque sample - */

                index += 20;
                builder = new StringBuilder();

                for (int i=0 ; i<size-20 ; i += 4) {
                    builder = new StringBuilder();
                    for (int j = 0; j < 4; j++)
                        builder.append(String.format("%02x", data[index + i + j]));
                    this.byteCountBySample.add(Integer.parseInt(builder.toString(), 16));
                    this.sizeRawData += Integer.parseInt(builder.toString(), 16);
                }

                break;

        }
    }

    public short[] computeDataToDraw() {

        int length = 0;
        for (Chunk c : this.chunks) length += c.getSamplesPerChunk();

        short[] values = new short[length];
        int indexTotal = 0;
        int indexSamples = 0;
        ByteBuffer wrapped = null;

        for (Chunk chunk : this.chunks) {
            indexTotal = chunk.getOffset();
            for (int i=0 ; i<chunk.getSamplesPerChunk() ; i++) {
                byte[] sample = new byte[this.byteCountBySample.get(indexSamples)];
                for(int j=0 ; j<this.byteCountBySample.get(indexSamples) ; j++) {
                    sample[j] = this.totalData[indexTotal + j];
                }
                wrapped = ByteBuffer.wrap(sample);
                values[indexSamples++] = wrapped.getShort();
                indexTotal += sample.length;
            }
        }

        return values;

    }

}
