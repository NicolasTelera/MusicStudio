package upmc.stl.m1.musicstudio.fragment;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import java.io.File;
import java.io.IOException;

import upmc.stl.m1.musicstudio.tools.Block;
import upmc.stl.m1.musicstudio.R;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TrackFragment_old.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TrackFragment_old#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TrackFragment_old extends Fragment {

    // Constante de chemin vers le repertoire de stockage
    public static final File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC + "/MusicStudio");

    // Listener de communication entre Activity et Fragment
    private OnFragmentInteractionListener listener;

    // Variables
    private int id;
    private String filename;
    private long duration;
    private boolean recording;
    private boolean playing;
    private MediaRecorder recorder;
    private MediaPlayer player;

    public static TrackFragment_old newInstance() {
        TrackFragment_old fragment = new TrackFragment_old();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    public TrackFragment_old() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle params = this.getArguments();
        this.id = params.getInt("id");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_track, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // LISTENER sur le bouton d'enregistrement
        Button buttonRecord = (Button) getView().findViewById(R.id.track_record_button);
        buttonRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("RECORDING");
                record(v);
            }
        });

        // LISTENER sur le bouton de lecture
        Button buttonPlay = (Button) getView().findViewById(R.id.track_play_button);
        buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("PLAYING");
                play();
            }
        });

        //Block block = new Block("test", 100, 200);
        //this.addBlock(block);

    }

    public void onButtonPressed(Uri uri) {
        if (listener != null) {
            listener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
        // on libère le recorder et le player
        try {
            this.recorder.release();
            this.player.release();
        } catch (Exception e) {
            Log.e("onDetach()", "release()");
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // on libère le recorder et le player
        try {
            this.recorder.release();
            this.player.release();
        } catch (Exception e) {
            Log.e("onDetach()", "release()");
        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        public void onFragmentInteraction(Uri uri);
    }

    /**********************************************************************************************
     *
     * FONCTIONS DE MANIPULATION DE LA PISTE
     *
     **********************************************************************************************/

    /**
     * Enregistre un son.
     * @param view
     */
    public void record(View view) {

        Button recordButton = (Button) getView().findViewById(R.id.track_record_button);

        if(this.recording) {

            recordButton.setText("RECORD");
            this.recorder.stop();
            this.duration = System.nanoTime() - this.duration;
            this.recorder.release();
            this.recording = false;

            Block block = new Block("test", 0, (int)((this.duration/1E9)*50));
            this.addBlock(block);

        } else {

            // préparation du micro
            this.recorder = new MediaRecorder();
            this.recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            this.recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            this.recorder.setOutputFile(this.path + "/audio_test" + this.id + ".mp4");
            this.recorder.setAudioEncoder(MediaRecorder.AudioEncoder.HE_AAC);

            try {
                this.recorder.prepare();
            } catch (IOException e) {
                Log.e("AudioRecordTest", "prepare() failed");
            }

            // modification du bouton
            recordButton.setText("STOP");

            // lancement de l'enregistrement
            this.duration = System.nanoTime();
            this.recorder.start();
            this.recording = true;

        }

    }

    /**
     * Lit un son préalablement enregistré.
     */
    public void play() {

        File file = new File(this.path + "/audio_test" + this.id + ".mp4");
        if(file.exists()) {

            Button playButton = (Button) getView().findViewById(R.id.track_play_button);

            if (this.playing) {

                playButton.setText("PLAY");
                this.player.release();
                this.playing = false;

            } else {

                try {
                    this.player = new MediaPlayer();

                    // ajout d'un listener sur le player pour remettre le bouton à "stop"
                    player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            Button playButton = (Button) getView().findViewById(R.id.track_play_button);
                            playButton.setText("PLAY");
                            playing = false;
                        }
                    });

                    this.player.setDataSource(this.path + "/audio_test" + this.id + ".mp4");
                    this.player.prepare();
                    this.player.start();

                } catch (IOException e) {
                    Log.e("AudioRecordTest", "prepare() failed");
                }

                playButton.setText("STOP");
                this.playing = true;

            }

        }

    }

    // fonction d'ajout d'un bloc sur une piste
    public void addBlock(final Block block) {

        // préparation d'un LinearLayout pour représenter le bloc
        LinearLayout layoutBlock = new LinearLayout(getActivity());
        //LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(new ActionBar.LayoutParams(block.getLength(), ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(block.getLength(), ViewGroup.LayoutParams.MATCH_PARENT);
        //params.setMargins(block.getLength(), 0, 0, 0);
        params.setMargins(block.getStart(), 0, 0, 0);
        layoutBlock.setLayoutParams(params);
        layoutBlock.setOrientation(LinearLayout.VERTICAL);
        layoutBlock.setBackgroundColor(0xfffffd11);


        // ajout d'un listener sur les mouvements du doigt pour déplacer le bloc
        layoutBlock.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int offset = (int) (event.getRawX() - v.getX());
                LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) v.getLayoutParams();
                if(event.getAction() == MotionEvent.ACTION_MOVE) {

                    int diff = 0;
                    int x = (int) v.getX();
                    int historySize = event.getHistorySize();
                    if(historySize > 0) {
                        diff = (int) (event.getX() - event.getHistoricalX(historySize -1));
                        if(diff > 0) {
                            x = x + diff;
                        } else {
                            x = x - Math.abs(diff);
                        }

                        if(x<0) x=0;
                        params.setMargins(x,0,0,0);
                        block.setStart(x);
                    }
                }
                v.setLayoutParams(params);
                return true;
            }
        });

        // ajout du block à la piste
        LinearLayout piste = (LinearLayout) getView().findViewById(R.id.track_sound_block);
        piste.addView(layoutBlock);

        // enregistrement du bloc dans la table de hachage
        //this.blocs.put(block, layoutBlock);

    }

}
