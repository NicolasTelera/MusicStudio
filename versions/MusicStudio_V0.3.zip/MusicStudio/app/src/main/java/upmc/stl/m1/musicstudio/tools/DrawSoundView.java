package upmc.stl.m1.musicstudio.tools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by nicolas on 04/03/2015.
 * Cette classe permet de dessiner les sons dans les blocs.
 */
public class DrawSoundView extends View {

    private Paint paint;
    private int center;
    private short[] data;

    public DrawSoundView(Context context, int height, short[] data) {
        super(context);
        this.center = height/2;
        this.data = data;
        this.paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
    }

    @Override
    public void onDraw(Canvas canvas) {

        /* ICI DESSINER DES TRAITS VERTICAUX ENTRE LES POINTS MIN ET MAX PAR PIXEl */
        int x = 0;
        for(short val : this.data) {
            canvas.drawLine(x, this.center+val, x, this.center-val, this.paint);
            x++;
        }

        /*
        if(this.data != null) {

            int x = 0;
            Point previous = new Point(0, 0);
            for(int i=0 ; i<this.data.length ; i++) {
                canvas.drawLine(previous.x, center+previous.y, x, center+((int)data[i]), this.paint);
                previous.x = x;
                previous.y = (int)data[i];
                x++;
            }

        }
        */
    }

}
