package upmc.stl.m1.musicstudio.tools;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/**
 * Classe de stockage des données relatives à un fichier MPEG4-v2.
 * Created by nicolas on 25/03/2015.
 */
public class Mpeg4Data {

    private ArrayList<Atom> atoms;
    private ArrayList<Chunk> chunks;
    private ArrayList<Integer> byteCountBySample; // stockage des taille des samples en bytes (samples dans l'ordre)
    private byte[] totalData;                     // (ArrayList car on doit la remplir avant de savoir sa taille)
    private byte[] rawData;

    public Mpeg4Data(byte[] data) {
        this.totalData = data;
        this.atoms = new ArrayList<Atom>();
        this.chunks = new ArrayList<Chunk>();
        this.byteCountBySample = new ArrayList<Integer>();
        this.rawData = new byte[0];
    }

    public ArrayList<Atom> getAtoms() {
        return this.atoms;
    }

    public void addAtom(Atom atom) {
        this.atoms.add(atom);
    }

    public Atom getAtomByName(String name) {
        for(Atom a : this.atoms)
            if(a.getName().equals(name)) return a;
        return null;
    }

    public void findMoovInfos() {

        byte[] data = this.getAtomByName("moov").getData();
        byte[] temp = new byte[4];
        StringBuilder builder = null;
        boolean done = false;
        int index = 8;
        int size = 0;
        String name = "";

        try {

            // parsing complet du fichier pour récupérer les 4 atomes principaux
            do {

                builder = new StringBuilder();
                Atom atom = new Atom(index);

                // récupération du nom de l'atome
                temp = new byte[4];
                for (int i=0 ; i<4 ; i++) temp[i] = data[index + i + 4];
                name = new String(temp, "UTF-8");

                //System.out.println("name : " + name);

                // si on est sur l'atome voulu, on descend d'un niveau
                // sinon on continue le traitement
                if (name.equals("trak")) index += 8;
                else if (name.equals("mdia")) index += 8;
                else if (name.equals("minf")) index += 8;
                else if (name.equals("stbl")) index += 8;
                else {

                    // récupération de la longueur de l'atome
                    for (int i=0 ; i<4 ; i++) builder.append(String.format("%02x", data[index + i]));
                    size = Integer.parseInt(builder.toString(), 16);

                    // parsing des atomes recherchés
                    if (name.equals("stsc") || name.equals("stco") ||  name.equals("stsz"))
                        this.parseAtom(name, index);

                    // vérification de la condition de sortie
                    if((index += size) >= data.length) done = true;

                }

            } while(!done);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        int cpt = 0;
        for(Chunk c : this.chunks) {
            System.out.println(c);
            for (int i=0 ; i<c.getSamplesPerChunk() ; i++) {
                System.out.println("- sample n°" + cpt +  " : " + this.byteCountBySample.get(cpt) + " bytes");
                cpt++;
            }
        }

    }

    public void parseAtom(String name, int index) {

        byte[] data = this.getAtomByName("moov").getData();
        StringBuilder builder = new StringBuilder();
        int size = 0;
        int cpt = 0;

        // récupération de la longueur de l'atome
        for (int i=0 ; i<4 ; i++) builder.append(String.format("%02x", data[index + i]));
        size = Integer.parseInt(builder.toString(), 16);

        switch(name) {


            case "stsc" : /* -- récupération du nombre de samples par chunk -- */

                index += 16;
                builder = new StringBuilder();
                for (int i=0 ; i<size-16 ; i += 12) {
                    Chunk chunk = new Chunk();
                    for (int j = 0; j < 4; j++) {
                        builder.append(String.format("%02x", data[index + i + j]));
                        chunk.setNum(Integer.parseInt(builder.toString(), 16));
                        builder = new StringBuilder();
                        builder.append(String.format("%02x", data[index + i + j + 4]));
                        chunk.setSamplesPerChunk(Integer.parseInt(builder.toString(), 16));
                        builder = new StringBuilder();
                        builder.append(String.format("%02x", data[index + i + j + 8]));
                        chunk.setSampleDescIndex(Integer.parseInt(builder.toString(), 16));
                    }
                    this.chunks.add(chunk);
                }

                break;

            case "stco" : /* -- récupération de l'offset (sur les données totales) des chunks - */

                index += 16;
                builder = new StringBuilder();

                for (int i=0 ; i<size-16 ; i += 4) {
                    builder = new StringBuilder();
                    for (int j = 0; j < 4; j++)
                        builder.append(String.format("%02x", data[index + i + j]));
                    this.chunks.get(cpt).setOffset(Integer.parseInt(builder.toString(), 16));
                    cpt++;
                }

                break;

                /*
                this.rawData = new byte[this.totalData.length - this.startIndex];
                this.fillRawData();
                */

            case "stsz" : /* -- récupération de la taille de chaque sample - */

                index += 20;
                builder = new StringBuilder();

                for (int i=0 ; i<size-20 ; i += 4) {
                    builder = new StringBuilder();
                    for (int j = 0; j < 4; j++)
                        builder.append(String.format("%02x", data[index + i + j]));
                    this.byteCountBySample.add(Integer.parseInt(builder.toString(), 16));
                }

                break;

        }
    }

    /**
     * Renseigne le tableau de raw data (uniquement les data (pas d'entête longueur + nom)
     */
    public void fillRawData() {

        for (int i=0 ; i<this.rawData.length ; i++) {}
            //this.rawData[i] = this.totalData[this.startIndex + i];

    }

    public short[] computeDataToDraw(int duration) {

        /**
         * --------------------------------------
         * ----- /!\ EN EXPERIMENTATION /!/ -----
         * --------------------------------------
         */

        int min = 0;
        int max = 0;
        //System.out.println("raw data length : " + this.rawData.length);
        //System.out.println("duration : " + duration);

        // parcours des raw data par fourchettes de "samplesPerPixel"
        // tentative sur des blocs de 16 bits
        short[] values = new short[this.rawData.length/16];
        byte[] sample = new byte[16];
        int compteur = 0;
        for (int i=0 ; i<this.rawData.length ; i+=16) {

            if(i + 16 < this.rawData.length) {

                sample = new byte[16];
                for (int j = 0; j < 16; j++) {
                    sample[j] = this.rawData[i + j];
                }
                ByteBuffer wrapped = ByteBuffer.wrap(sample);
                short num = wrapped.getShort();
                values[compteur] = num;
                compteur++;

            } else break;

        }
        int samplesPerPixel = values.length / duration;
        //System.out.println("values lenght : " + values.length);
        //System.out.println("samples per pixel : " + samplesPerPixel);

        ArrayList<short[]> pairs = new ArrayList<short[]>();
        ArrayList<int[]> pairsInt = new ArrayList<int[]>();
        for (int i=0 ; i<values.length ; i += samplesPerPixel) {

            int[] pair = new int[2];
            min = 1000;
            max = 0;

            // recherche du max et du min de la fourchette en cours

            for(int j=i ; j<(i+samplesPerPixel) ; j++) {
                if(j >= values.length) break;
                if (values[j] < min) {
                    min = values[j];
                    pair[0] = min;
                }
                if (values[j] > max) {
                    max = values[j];
                    pair[1] = max;
                }
            }

            /*
            // modif taille
            compteur = 0;
            for (short[] p : pairs) {
                pairsInt[compteur] = ;
            }

            for (int[] p : pairs) {
                System.out.println("x = " + p[0] + " et y = " + p[1]);
            }

            // ajout de la paire "min & max" dans les valeurs à retourner
            pairs.add(pair);
            */

        }

        // puis division sur la largeur des pixels
        /*
        short[] returned = new short[duration];
        for(int i=0 ; i<47 ; i++) {
            for(int j=0 ; j<16 ;j++) {
                returned[i] = values[j];
            }
            //returned[i] = returned[i] / 16;
        }
        */

        /**
         * --------------------------------------
         * ----- /!\ FIN EXPERIMENTATION /!/ ----
         * --------------------------------------
         */

        return null;


        /*
        for (int i=0 ; i<this.rawData.length ; i += samplesPerPixel) {

            int[] pair = new int[2];
            min = 1000;
            max = 0;

            // recherche du max et du min de la fourchette en cours
            for(int j=i ; j<(i+samplesPerPixel) ; j++) {
                if(j >= this.rawData.length) break;
                if (this.rawData[j] < min) {
                    System.out.println("min : " + this.rawData[j]);
                    min = this.rawData[j];
                    pair[0] = min;
                }
                if (this.rawData[j] > max) {
                    System.out.println("max : " + this.rawData[j]);
                    max = this.rawData[j];
                    pair[1] = max;
                }
            }

            System.out.println("x = " + pair[0] + " et y = " + pair[1]);

            // ajout de la paire "min & max" dans les valeurs à retourner
            values.add(pair);

        }
        */

    }

}
